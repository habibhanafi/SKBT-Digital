let step=1;
let death=false;

const basic=[
 ["Surat Pengantar dari Dinas","suratPengantar"],
 ["SK Terakhir","skTerakhir"],
 ["KTP","ktp"],
 ["Riwayat Jabatan","riwayatJabatan"]
];

const heirs=[
 ["KTP Ahli Waris","ktpAhliWaris"],
 ["Surat Keterangan Meninggal","suratMeninggal"],
 ["Surat Ahli Waris","suratAhliWaris"]
];

function uploadHTML(items){
 return items.map(x=>`
 <div class="upload">
   <label>${x[0]} *</label>
   <div class="drop">
     <span style="font-size:24px;color:#1457a6">↑</span>
     <strong>Pilih file</strong>
     <small>PDF / JPG / PNG — maksimal 5 MB</small>
     <input type="file" id="${x[1]}" accept=".pdf,.jpg,.jpeg,.png" required>
     <div class="fname" id="${x[1]}Name"></div>
   </div>
 </div>`).join("");
}

document.getElementById("docs").innerHTML=uploadHTML(basic);
document.getElementById("heirDocs").innerHTML=uploadHTML(heirs);

document.getElementById("keperluan").addEventListener("change",function(){
 death=this.value==="Pemberhentian Karena Meninggal Dunia";
 document.getElementById("heirSection").classList.toggle("show",death);

 heirs.forEach(x=>{
   document.getElementById(x[1]).required=death;
 });
});

document.addEventListener("change",function(e){
 if(e.target.type!=="file")return;
 const file=e.target.files[0];
 if(!file)return;

 const output=document.getElementById(e.target.id+"Name");
 if(file.size>5*1024*1024){
   alert("Ukuran file maksimal 5 MB.");
   e.target.value="";
   output.textContent="";
   return;
 }

 if(!["application/pdf","image/jpeg","image/png"].includes(file.type)){
   alert("Format file harus PDF, JPG, atau PNG.");
   e.target.value="";
   output.textContent="";
   return;
 }

 output.textContent="✓ "+file.name;
});

function valid(n){
 const section=document.getElementById("s"+n);
 for(const input of section.querySelectorAll("input,select")){
   if(!input.checkValidity()){
     input.reportValidity();
     return false;
   }
 }
 return true;
}

function next(){
 if(step===1){
   if(!valid(1))return;
   step=2;
 }else if(step===2){
   if(!valid(2))return;
   step=3;
 }
 show();
}

function prev(){
 if(step===3)step=2;
 else if(step===2)step=1;
 show();
}

function show(){
 document.querySelectorAll(".step").forEach(x=>x.classList.remove("active"));
 document.getElementById("s"+step).classList.add("active");

 for(let i=1;i<=3;i++){
   const p=document.getElementById("p"+i);
   p.classList.toggle("active",i===step);
   p.classList.toggle("done",i<step);
 }
 document.getElementById("l1").classList.toggle("on",step>=2);
 document.getElementById("l2").classList.toggle("on",step>=3);

 if(step===3)review();
 window.scrollTo({top:0,behavior:"smooth"});
}

function val(id){
 return document.getElementById(id).value;
}

function review(){
 const data=[
  ["Keperluan","keperluan"],
  ["Nama","nama"],
  ["NIP","nip"],
  ["Pangkat/Golongan","pangkat"],
  ["Jabatan","jabatan"],
  ["Instansi","instansi"],
  ["Unit Kerja","unit"],
  ["WhatsApp","wa"],
  ["Email","email"]
 ];

 document.getElementById("review").innerHTML=data.map(x=>
   `<div class="row"><span>${x[0]}</span><b>${val(x[1])}</b></div>`
 ).join("");

 const all=death?basic.concat(heirs):basic;

 document.getElementById("reviewDocs").innerHTML=all.map(x=>{
   const f=document.getElementById(x[1]).files[0];
   return `<li>✓ ${x[0]}: ${f?f.name:"-"}</li>`;
 }).join("");
}

document.getElementById("form").addEventListener("submit",function(e){
 e.preventDefault();

 if(!document.getElementById("final").checked){
   alert("Centang konfirmasi terlebih dahulu.");
   return;
 }

 const no="SKBT-"+new Date().getFullYear()+"-"+Math.floor(1000+Math.random()*9000);

 document.getElementById("number").textContent=no;
 document.getElementById("form").style.display="none";
 document.querySelector(".progress").style.display="none";
 document.getElementById("success").classList.add("show");
 window.scrollTo({top:0,behavior:"smooth"});
});
